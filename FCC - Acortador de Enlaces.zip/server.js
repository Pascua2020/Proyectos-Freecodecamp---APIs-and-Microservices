/* 
El modo estricto tiene varios cambios en la semántica normal de JavaScript:

Elimina algunos errores silenciosos de JavaScript cambiándolos para que lancen errores.
Corrige errores que hacen difícil para los motores de JavaScript realizar optimizaciones: a veces, el código en modo estricto puede correr más rápido que un código idéntico pero no estricto.
Prohíbe cierta sintaxis que probablemente sea definida en futuras versiones de ECMAScript.*/
'use strict';

var express = require('express');
var mongo = require('mongodb');
var mongoose = require('mongoose');
/*The dns module enables name resolution. For example, use it to look up IP addresses of host names.

Although named for the Domain Name System (DNS), it does not always use the DNS protocol for lookups.*/
const dns = require('dns');
const bodyParser = require('body-parser');

var cors = require('cors');

var app = express();

//console.log("---mongo---",mongo,"---mongoose---",mongoose,"---dns---",dns,"---bodyParser---",bodyParser)

// Basic Configuration 
var port = process.env.PORT || 3000; // sin esto el programa no funciona.

/** this project needs a db !! **/ 
// mongoose.connect(process.env.DB_URI);

app.use(cors());

/** this project needs to parse POST bodies **/
// you should mount the body-parser here

app.use(bodyParser.urlencoded({ extended: false })); // sin esto tira este error : TypeError: Cannot destructure property 'url' of 'req.body' as it is undefined. 
app.use('/public', express.static(process.cwd() + '/public')); // sin el public el programa pierde el formato visual.
console.log("---process.cwd()",process.cwd())
/*The express.static() function is a built-in middleware function in Express. It serves static files and is based on serve-static.

The process.cwd() method is an inbuilt application programming interface of the process module which is used to get the current working directory of the node.js process.*/ 

app.get('/', function(req, res){
  res.sendFile(process.cwd() + '/views/index.html'); // sin esto el programa no carga.
});

const links = []; // aca se guarda cada link,como por ej link { original_url: 'https://www.freecodecamp.org', short_url: '1' }: 

let id = 0; // aca se guarda el id de cada pagina web cuyo link se acorta.

app.post('/api/shorturl/new', (req, res) => {
  const { url } = req.body; // EJ : {"url":"https://www.freecodecamp.org"}
  
  const noHTTPSurl = url.replace(/^https?:\/\//, ''); // EJ : www.freecodecamp.org

  //res.send(noHTTPSurl)

  // check if this url is valid
  // dns.lookup() uses the operating system facilities to perform name resolution. It may not need to perform any network communication. To perform name resolution the way other applications on the same system do, use dns.lookup().
  dns.lookup(noHTTPSurl, (err) => {
    if(err) {
      return res.json({
        error: "invalid URL"
      });
    } else {
      // increment id
      id++;
      
      // create new entry for our arr
      const link = {
        original_url: url,
        short_url: `${id}`
      };
      
      links.push(link);
      
      console.log("---links",links);
      //console.log(res.json(link)) esto rompe el programa.
      // return this new entry
      return res.json(link); // sin esto el boton POST URL no hace nada.
    }
  });
});


app.get('/api/shorturl/:id', (req, res) => {
  const { id } = req.params; // EJ : 3
  
  // EJ: id from query 3
  console.log('id from query', id)
  
  const link = links.find(l => l.short_url === id); // busca que la url corta tenga el mismo numero que el id que se refiere al url original.
  
  console.log('link found', link);
  /*link found { original_url: 'vandal.net', short_url: '3' }*/
  
  if(link) {
    // Redirects to the URL derived from the specified path, with specified status, a positive integer that corresponds to an HTTP status code . If not specified, status defaults to “302 “Found”.
    return res.redirect(link.original_url); // sin esto no redirige al entrar en el link.
  } else {
    return res.json({
      error: 'No short url / No hay url corta'
    });
  }
});

// sin app.listen se queda cargando sin terminar.
app.listen(port, function () {
  console.log('Node.js listening ...');
});

/*ej: {"original_url":"infobae.com","short_url":"1"}
para acceder a la url en el navegador,tengo que poner:

https://thread-paper.glitch.me/api/shorturl/3

( en el caso de abrirla desde glitch

( https://glitch.com/edit/#!/open-silent-talon?path=server.js%3A87%3A3 ) ) */