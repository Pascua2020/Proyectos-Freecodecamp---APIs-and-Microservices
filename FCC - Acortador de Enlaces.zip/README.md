# [URL Shortener Microservice](https://www.freecodecamp.org/learn/apis-and-microservices/apis-and-microservices-projects/url-shortener-microservice)

Package.json
Hyperdev: HyperDev is a developer playground that lets you just focus on writing code. By removing the barriers to building, HyperDev gets you straight to developing real web apps, in a fast, fun and collaborative way.

Los links deben ir en este formato : "https://www.google.com" y no mas incompleto ( como por ej,"google.com" ),porque de lo contrario no funcionaran.