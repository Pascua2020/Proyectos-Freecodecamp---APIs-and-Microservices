# [Exercise Tracker](https://www.freecodecamp.org/learn/apis-and-microservices/apis-and-microservices-projects/exercise-tracker)

Nombre Archivos Glitch:
1-lean-natural-cough : exercise tracker
https://glitch.com/edit/#!/lean-natural-cough?path=package.json%3A1%3A0

2-voltaic-whispering-lodge : file metadata
https://glitch.com/edit/#!/voltaic-whispering-lodge?path=package.json%3A1%3A0

3-iron-spiced-holiday : timestamp
https://glitch.com/edit/#!/iron-spiced-holiday?path=package.json%3A1%3A0

4-open-silent-talon : url-shortener
https://glitch.com/edit/#!/open-silent-talon?path=server.js%3A87%3A3

5-glorious-sparkly-flea : request header parser
https://glitch.com/edit/#!/glorious-sparkly-flea?path=server.js%3A40%3A0

Package.JSON
// Mongoose: Mongoose es una librería object-document mapping (ODM) para MongoDB. Las ventajas de utilizar un ODM son muchas y van mas allá de la organización del código o del desarrollo sencillo. Mongoose abstrae todo de la base de datos, y el código de la aplicación interactúa solo con los objetos y sus métodos.
MongoDB : MongoDB es una base de datos orientada a documentos. Esto quiere decir que en lugar de guardar los datos en registros, guarda los datos en documentos. Estos documentos son almacenados en BSON, que es una representación binaria de JSON.
BodyParser : Body-parser is the Node. js body parsing middleware. It is responsible for parsing the incoming request bodies in a middleware before you handle it. Installation of body-parser module: You can visit the link to Install body-parser module.
Shortid: shortid is deprecated, because the architecture is unsafe. we instead recommend Nano ID, which has the advantage of also being significantly faster than shortid
ShortId creates amazingly short non-sequential url-friendly unique ids. Perfect for url shorteners, MongoDB and Redis ids, and any other id users might see.
Gomix: With Gomix, you don’t have to manage the confusing or complex parts of creating an app or bot. You start with a working app, hosted on the latest cloud infrastructure. If you’re an advanced developer, you can just start with your favorite web frameworks (it’s regular Node.js, but without any of the hassle.). From there, you just remix these working examples into the app of your dreams.