// link : https://boilerplate-project-exercisetracker.gonzaloescuder2.repl.co

const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const shortid = require('shortid');

const cors = require('cors')

// si esto se pone sin comentario tira error de conexion.
//const mongoose = require('mongoose')

//mongoose.connect(process.env.MLAB_URI || 'mongodb://localhost/exercise-track' )
// creo que mLab uri - url set by process.env in server.js.

app.use(cors())

//console.log("shortid",shortid)
// urlencoded() is a method inbuilt in express to recognize the incoming Request Object as strings or arrays. This method is called as a middleware in your application using the code: app.
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())


app.use(express.static('public'))
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html')
});

//console.log("__dirname",__dirname)

// HERE WE ARE GOING TO DO OUR MAGIC!!

// These are from the frontend forms
// ON '/api/exercise/new-user' WE GET     username
// ON '/api/exercise/add'      WE GET     userId description duration date
// ID FOR TESTING: Hk90m8HHL

// 0. Create our local DATABASE
const users = [];
const exercises = [];

// CUSTOM FUNCTIONS
const getUsernameById = (id) => users.find(user => user._id === id).username; // con esto se busca el nombre de usuario a traves del id que se tiene.

const getExercisesFromUserWithId = (id) => exercises.filter(exe => exe._id === id); // con esto se filtran los ejercicios que son del id escrito.

// 1. I can create a user by posting form data username to 
// /api/exercise/new-user and returned will be an object with username and _id.

app.post('/api/exercise/new-user', (req, res) => {
  // EJ : {"username":"harry potter","_id":"e5s6JTHUj"}
  const { username } = req.body;
  
  const newUser = {
    username,
    _id: shortid.generate() // esto genera un id aleatorio.
  }
  
  users.push(newUser);
  
  return res.json(newUser);
});

// 2. I can get an array of all users by getting api/exercise/users 
// with the same info as when creating a user.

app.get('/api/exercise/users', (req, res) => {
  /*EJ : [{"username":"ricardo","_id":"8iFYfU_YH"},{"username":"hhh","_id":"65nmxN2Ur"},
  {"username":"hhh","_id":"L-44HjWPu"},
  {"username":"harry potter","_id":"e5s6JTHUj"}]*/
  return res.json(users);
});


// 3. I can add an exercise to any user by posting form data 
// userId(_id), description, duration, and optionally date to /api/exercise/add. 
// If no date supplied it will use current date. 
// Returned will be the user object with also with the exercise fields added.
app.post('/api/exercise/add', (req, res) => {

  /*EJ : {"_id":"e5s6JTHUj","description":"hola","duration":111,"date":"Mon Aug 23 2021 14:18:14 GMT+0000 (Coordinated Universal Time)"}*/
  const { userId, description, duration, date } = req.body;
  
  // req.body : Contains key-value pairs of data submitted in the request body. By default, it is undefined, and is populated when you use body-parsing middleware such as express.json() or express.urlencoded().
  
  // IMPORTANT! we are assuming that the data coming from the form is correct!
  
  // si no se ingresa fecha se creara una nueva,como por ej : "Mon Aug 23 2021 14:18:14 GMT+0000 (Coordinated Universal Time)"
  const dateObj = date === '' ? new Date() : new Date(date);
  
  const newExercise = {
    _id: userId,
    description,
    // el signo + convierte a numero,de lo contrario es string.
    duration: +duration,
    date: dateObj.toString()
    // sin el toString la fecha seria por ej : "2021-08-23T14:21:40.126Z"
  }
  
  exercises.push(newExercise);
  
  res.json(newExercise);
});


// 4. I can retrieve a full exercise log of any user by getting 
// /api/exercise/log with a parameter of userId(_id). Return will be the user 
// object with added array log and count (total exercise count).

// 5. I can retrieve part of the log of any user by also passing 
// along optional parameters of from & to or limit. (Date format yyyy-mm-dd, limit = int)

app.get('/api/exercise/log', (req, res) => {
  /*EJ LINK : https://fcc-5-project-exercisetracker.gonzaloescuder2.repl.co/api/exercise/log?userId=Q-ROEy51M
  
  {"_id":"Q-ROEy51M","username":"ricardo","count":2,"log":[
  {"_id":"Q-ROEy51M","description":"aaa","duration":1111,"date":"Sun Feb 02 2020 00:00:00 GMT+0000 (Coordinated Universal Time)"},
  {"_id":"Q-ROEy51M","description":"bbb","duration":2222,"date":"Fri Jan 01 2021 00:00:00 GMT+0000 (Coordinated Universal Time)"}
  ]}

  https://fcc-5-project-exercisetracker.gonzaloescuder2.repl.co/api/exercise/log?userId=Q-ROEy51M&from=2021

  https://fcc-5-project-exercisetracker.gonzaloescuder2.repl.co/api/exercise/log?userId=Q-ROEy51M&from=2021&to=2022

  {"_id":"Q-ROEy51M","username":"ricardo","count":1,"log":[{"_id":"Q-ROEy51M","description":"bbb","duration":2222,"date":"Fri Jan 01 2021 00:00:00 GMT+0000 (Coordinated Universal Time)"}]}

  https://fcc-5-project-exercisetracker.gonzaloescuder2.repl.co/api/exercise/log?userId=Q-ROEy51M&limit=3

  {"_id":"Q-ROEy51M","username":"ricardo","count":2,"log":[{"_id":"Q-ROEy51M","description":"aaa","duration":1111,"date":"Sun Feb 02 2020 00:00:00 GMT+0000 (Coordinated Universal Time)"},
  {"_id":"Q-ROEy51M","description":"bbb","duration":2222,"date":"Fri Jan 01 2021 00:00:00 GMT+0000 (Coordinated Universal Time)"}]}

  */

  // req.query : This property is an object containing a property for each query string parameter in the route. When query parser is set to disabled, it is an empty object {}, otherwise it is the result of the configured query parser.
  const { userId, from, to, limit } = req.query; //{}
  
  let log = getExercisesFromUserWithId(userId); //[]
  //res.send(log);
  // IMPORTANT! we are assuming that the data coming from the form is correct!
  
  //console.log("log",log)

  if(from) {
    const fromDate = new Date(from);
    /*EJ : https://fcc-5-project-exercisetracker.gonzaloescuder2.repl.co/api/exercise/log?userId=EqAxS9VZE&from=2020
    
    "2020-01-01T00:00:00.000Z" */
    
    log = log.filter(exe => new Date(exe.date) >= fromDate); // EJ: 2021 >= 2020
    
  }
  
  if(to) {
    const toDate = new Date(to);
    /*EJ : https://fcc-5-project-exercisetracker.gonzaloescuder2.repl.co/api/exercise/log?userId=Xgt8lTdcB&to=2021
    
    "2021-01-01T00:00:00.000Z" */
    
    log = log.filter(exe => new Date(exe.date) <= toDate); // EJ : 2021 <= 2022
  }
  
  if(limit) {
    log = log.slice(0, +limit); // sin esto no se filtra.
    // EJ : (0,2) = (2) [1,2]
  }
  
  res.json({
    _id: userId,
    username: getUsernameById(userId),
    count: log.length,
    log
  });
});

// Not found middleware
/*El término middleware se refiere a un sistema de software que ofrece servicios y funciones comunes para las aplicaciones. En general, el middleware se encarga de las tareas de gestión de datos, servicios de aplicaciones, mensajería, autenticación y gestión de API.*/
app.use((req, res, next) => {
  // que es next? , seguramente sirve para devolver un tipo de error.
  return next({status: 404, message: 'not found'})
})

// Error Handling middleware
app.use((err, req, res, next) => {
  // req : request, res : response
  let errCode, errMessage
  
  if (err.errors) {
    // mongoose validation error
    errCode = 400 // bad request / solicitud incorrecta
    const keys = Object.keys(err.errors) // que es?
    // report the first validation error
    errMessage = err.errors[keys[0]].message // que devuelve?

  } else {
    // generic or custom error / error generico o personalizado
    errCode = err.status || 500
    errMessage = err.message || 'Internal Server Error'
  }
  //console.log("---errCode:",errCode,"---errMessage:",errMessage)

  res.status(errCode).type('txt')
    .send("errMessage") // esto seguramente debe devolver el tipo de error.
});

// process.env.PORT || 3000 means: whatever is in the environment variable PORT, or 3000 if there's nothing there.

// So you pass that to app.listen, or to app.set('port', ...), and that makes your server able to accept a "what port to listen on" parameter from the environment.
const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port) // ej port : 3000
})

/*error : not found

ej usuario :
{"username":"ricardo","_id":"dwMZ-Lo0c"}

ej ejercicios:
{"_id":"dwMZ-Lo0c","description":"jaja","duration":1,"date":"Sun Aug 15 2021 19:40:50 GMT+0000 (UTC)"}
o
{"_id":"a","description":"a","duration":2,"date":"Wed Jan 01 2020 00:00:00 GMT+0000 (UTC)"} */