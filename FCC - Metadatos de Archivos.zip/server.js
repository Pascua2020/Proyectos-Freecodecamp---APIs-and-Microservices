// link : https://boilerplate-project-filemetadata.gonzaloescuder2.repl.co
'use strict';

var express = require('express');
var cors = require('cors');
var multer  = require('multer') // sin esto no se sube el archivo.
// dest : destination directory.
var upload = multer({ dest: 'uploads/' }) // sin esto no puede subir el archivo.

//console.log("---express---",express,"---cors---",cors,"---multer---",multer,"---upload---",upload)
// require and use "multer"...

var app = express();

//console.log("---app---",app)
app.use(cors());
//console.log("---app.use(cors())---",app.use(cors()))
app.use('/public', express.static(process.cwd() + '/public'));

//console.log("---app.use('/public', express.static(process.cwd() + '/public'));---",app.use('/public', express.static(process.cwd() + '/public')))

app.get('/', function (req, res) {
     res.sendFile(process.cwd() + '/views/index.html');
     //console.log("process.cwd()",process.cwd())
  });

/*The app.post() function routes the HTTP POST requests to the specified path with the specified callback functions.

creo que upload.single sube un archivo online.*/

/*Esto tiene que ver con el html,
<form enctype="multipart/form-data" method="POST" action="/api/fileanalyse">

            <input id="inputfield" type="file" name="upfile">*/
app.post('/api/fileanalyse', upload.single('upfile'), function(req, res){
  const { originalname: name, mimetype: type, size } = req.file;
  
  //console.log("req.file",req.file);

  /*EJ req.file {
  fieldname: 'upfile',
  originalname: 'Disc 2.jpg',
  encoding: '7bit',
  mimetype: 'image/jpeg',
  destination: 'uploads/',
  filename: 'a5e6ee6f01eb76699839717ceb28796e',
  path: 'uploads/a5e6ee6f01eb76699839717ceb28796e',
  size: 75741
} */

  res.json({
    name,
    type,
    size
  });
});

// {
// name: "url.png",
// type: "image/png",
// size: 815214
// }

/*ej:
{"name":"use-dynamic-scales.txt",
"type":"text/plain",
"size":1061}*/

app.listen(process.env.PORT || 3000, function () {
  console.log('Node.js listening ...');
});
