// link : https://boilerplate-project-timestamp.gonzaloescuder2.repl.co
// server.js
// where your node app starts

// init project
// Requires the Express module just as you require other modules and and puts it in a variable. 
var express = require('express');
var app = express(); // sin esto el programa no funciona.

// enable CORS (https://en.wikipedia.org/wiki/Cross-origin_resource_sharing)
// so that your API is remotely testable by FCC 
var cors = require('cors');
// The app.use() function is used to mount the specified middleware function(s) at the path which is being specified. It is mostly used to set up middleware for your application.
app.use(cors({optionSuccessStatus: 200}));  // some legacy browsers choke (ahogo?) on 204

// http://expressjs.com/en/starter/static-files.html
app.use(express.static('public')); // sin esto el programa no tiene estilo.

// http://expressjs.com/en/starter/basic-routing.html
// The app.get() function returns the value name app setting. The app.set() function is used to assigns the setting name to value. This function is used to get that values which are assigned.

// sin este app.get pone "Cannot GET /"
app.get("/", function (req, res) {
  // Transfers the file at the given path. Sets the Content-Type response HTTP header field based on the filename’s extension. Unless the root option is set in the options object, path must be an absolute path to the file.
  res.sendFile(__dirname + '/views/index.html'); // sin esto el programa nunca carga.
  console.log("__dirname",__dirname)
  console.log(__dirname + '/views/index.html')
});


// eg: https://curse-arrow.hyperdev.space/api/timestamp/2015-12-15
// functions {"unix": <date.getTime()>, "utc" : <date.toUTCString()> }

// req es un objeto que contiene información sobre la solicitud HTTP que provocó el evento. En respuesta a req , usa res para devolver la respuesta HTTP deseada.

// sin este app.get creo que el programa funciona pero porque hay otro app.get tras esto.
app.get("/api/timestamp", (req, res) => {
  res.send('hello from timestamp'); // escribo un comentario en la web "/api/timestamp".
  const date = new Date();
  // res.json : Sends a JSON response composed of the specified data.

  res.json({
    // The getTime() method returns the number of milliseconds between midnight of January 1, 1970 and the specified date.
    unix: date.getTime(),
    // toUTCString() method is used to convert the given date object's contents into a string according to universal time zone UTC. The date object is created using date() constructor. 
    utc: date.toUTCString()
  })
});

// your first API endpoint... 

/*
Los endpoints son las URLs de un API o un backend que responden a una petición. Los mismos entrypoints tienen que calzar con un endpoint para existir. Algo debe responder para que se renderice un sitio con sentido para el visitante.

backend: El backend es la parte del desarrollo web que se encarga de que toda la lógica de una página web funcione. Se trata del conjunto de acciones que pasan en una web pero que no vemos como, por ejemplo, la comunicación con el servidor.

Entry point es la URL que el visitante habrá ingresado en su navegador para ver su aplicación o sitio. Antiguamente, cada sección de un sitio web era un entrypoint.*/
app.get("/api/timestamp/:date_str", function (req, res) {
  // params. An object containing parameter values parsed from the URL path. For example if you have the route /user/:name , then the "name" from the URL path wil be available as req.params.name .
  const { date_str } = req.params;
  // req.params : {"date_str":"2015-12-25"}

  // new Date() seria : "2021-08-22T14:06:21.188Z"
  let date = new Date(date_str); 
  // The toString() method returns a string representing the specified Date object.
  if(date.toString() === 'Invalid Date') {
    // tries again by converting it from unix (which needs to be a number)
    // parseInt: Convierte (parsea) un argumento de tipo cadena y devuelve un entero de la base especificada.
    date = new Date(parseInt(date_str)); // sin esto,abajo se mostrara "Invalid Date".
    /* new Date(parseInt(date_str) : "1970-01-01T00:00:02.015Z

    date_str seria : "2015-12-25"

    parseInt(date_str) = 2015*/
  }
  
  /* date.toString seria,por ej:
      "Fri Dec 25 2015 00:00:00 GMT+0000 (Coordinated Universal Time)"*/
  if(date.toString() === 'Invalid Date') {
    return res.json({
      error: "Invalid Date" 
    });
  } else {
    return res.json({
      /*aca se devuelve el valor que se imprime en pantalla al ingresar a alguno de los links
      
      EJ:[project url]/api/2015-12-25
      "unix":1451001600000
      "utc":"Fri, 25 Dec 2015 00:00:00 GMT"

      con date solo el formato seria : "2015-12-25T00:00:00.000Z".
      */
      unix: date.getTime(),
      utc: date.toUTCString()
    })
  }
});
// listen for requests :)
// The app.listen() function is used to bind and listen the connections on the specified host and port. This method is identical to Node’s http.Server.listen() method.

// If the port number is omitted or is 0, the operating system will assign an arbitrary unused port, which is useful for cases like automated tasks (tests, etc.).

// Con el objeto process, disfrutaremos del acceso a las variables de entorno de una manera asequible. Usaremos la propiedad env y, a continuación, el nombre de la variable a la que necesitamos acceder.

// En este ejemplo a la variable de entorno, a la que llamamos PORT, se accedería de este modo:
// sin esta funcion el programa no funciona.
var listener = app.listen(process.env.PORT, function () {
  console.log('Your app is listening on port ' + listener.address().port);
  // console.log(process.env.PORT) devuelve undefined.
  // EJ listener.address().port : 41971 .
  // sin port dice : [object Object]
  // address : Get current machine IP, MAC and DNS servers.
});

/*MAS EJ:
https://fcc-5-project-timestamp.gonzaloescuder2.repl.co/api/timestamp/2020-25-25 ( con - o con espacios)
{"unix":2020,"utc":"Thu, 01 Jan 1970 00:00:02 GMT"}

https://fcc-5-project-timestamp.gonzaloescuder2.repl.co/api/timestamp/2020
{"unix":1577836800000,"utc":"Wed, 01 Jan 2020 00:00:00 GMT"}

https://fcc-5-project-timestamp.gonzaloescuder2.repl.co/api/timestamp/2020-03
{"unix":1583020800000,"utc":"Sun, 01 Mar 2020 00:00:00 GMT"}

https://fcc-5-project-timestamp.gonzaloescuder2.repl.co/api/timestamp/1968
{"unix":-63158400000,"utc":"Mon, 01 Jan 1968 00:00:00 GMT"}

https://fcc-5-project-timestamp.gonzaloescuder2.repl.co/api/timestamp/63172005000
{"unix":63172005000,"utc":"Sun, 02 Jan 1972 03:46:45 GMT"}
*/