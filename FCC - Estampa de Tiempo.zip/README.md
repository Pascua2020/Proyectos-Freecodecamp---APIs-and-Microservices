
# [Timestamp Microservice](https://www.freecodecamp.org/learn/apis-and-microservices/apis-and-microservices-projects/timestamp-microservice)

// COMENTARIOS "PACKAGE.JSON" ( NO FUNCIONA SI SE PONEN COMENTARIOS EN EL ARCHIVO.) ( los comentarios en server.js SI funcionan.)
{
  /*name:If you plan to publish your package, the most important things in your package.json are the name and version fields as they will be required. The name and version together form an identifier that is assumed to be completely unique. Changes to the package should come along with changes to the version. If you don't plan to publish your package, the name and version fields are optional.*/
	"name": "fcc-api-projects-boilerplate",
  /*version:If you plan to publish your package, the most important things in your package.json are the name and version fields as they will be required. The name and version together form an identifier that is assumed to be completely unique. Changes to the package should come along with changes to the version. If you don't plan to publish your package, the name and version fields are optional.*/
	"version": "0.0.1",
  /*description:This document is all you need to know about what's required in your package.json file. It must be actual JSON, not just a JavaScript object literal.

A lot of the behavior described in this document is affected by the config settings described in config.*/
	"description": "An FCC Backend Challenge",
  /*main:The main field is a module ID that is the primary entry point to your program. That is, if your package is named foo, and a user installs it, and then does require("foo"), then your main module's exports object will be returned.*/
	"main": "server.js",
  /*scripts:The "scripts" property is a dictionary containing script commands that are run at various times in the lifecycle of your package. The key is the lifecycle event, and the value is the command to run at that point.*/
	"scripts": {
    /*If there is a server.js file in the root of your package, then npm will default the start command to node server.js.*/
		"start": "node server.js"
	},
  /*Dependencies are specified in a simple object that maps a package name to a version range. The version range is a string which has one or more space-separated descriptors. Dependencies can also be identified with a tarball or git URL.*/
	"dependencies": {
    /*Express.js, o simplemente Express, es un marco de aplicación web de back-end para Node.js, lanzado como software gratuito y de código abierto bajo la licencia MIT. Está diseñado para crear aplicaciones web y API. Se le ha llamado el marco de servidor estándar de facto para Node.js.*/
		"express": "^4.12.4",
    /*CORS is a node.js package for providing a Connect/Express middleware that can be used to enable CORS with various options.*/
		"cors": "^2.8.0"
	},
	"engines": {
    /*You can specify the version of node that your stuff works on:*/
		"node": "4.4.5"
	},
  /*Specify the place where your code lives. This is helpful for people who want to contribute. If the git repo is on GitHub, then the npm docs command will be able to find you.*/
	"repository": {
		"type": "git",
		"url": "https://githost.com/camper/repo.git"
	},
  /*Put keywords in it. It's an array of strings. This helps people discover your package as it's listed in npm search.*/
	"keywords": [
		"node",
		"hyperdev",
		"express",
		"freecodecamp"
	],
  /*You should specify a license for your package so that people know how they are permitted to use it, and any restrictions you're placing on it.*/
	"license": "MIT"
  /*Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/
}